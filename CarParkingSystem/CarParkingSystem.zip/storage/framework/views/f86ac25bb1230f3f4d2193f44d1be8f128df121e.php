
<?php $__env->startSection('main-content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
        <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card bg-primary text-white mb-4">
                    <div class="card-body">Total number of users:</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <?php echo e($data['user']); ?>

                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card bg-primary text-white mb-4">
                    <div class="card-body">Total number of reservations:</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <?php echo e($data['res']); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <h5>Today's reservation (<?php echo e($data['today']->format('d/m/Y')); ?>) :</h5>
            <br>
        </div>
            <div class="row">
            <div class="col-xl-3 col-md-6">
                <div class="card bg-primary text-white mb-4">
                    <div class="card-body">Total number of reservations:</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <?php echo e($data['restoday']); ?>

                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card bg-warning text-white mb-4">
                    <div class="card-body">On-going Reservation</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <?php echo e($data['pending']); ?>

                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card bg-success text-white mb-4">
                    <div class="card-body">Completed Reservation</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <?php echo e($data['success']); ?>

                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card bg-danger text-white mb-4">
                    <div class="card-body">Cancelled Reservation</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <?php echo e($data['cancel']); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-chart-area mr-1"></i>
                        Today's reservations
                    </div>
                    <div class="card-body">
                        <?php if(empty($data['records'][0]->id)): ?>
                            No reservations have been made
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th scope="col"> Id</th>
                                            <th scope="col"> Date </th>
                                            <th scope="col"> Start Time </th>
                                            <th scope="col"> End Time</th>
                                            <th scope="col"> Parking Level</th>
                                            <th scope="col"> Parking ID </th>
                                            <th scope="col"> Car Plate</th>
                                            <th scope="col"> Status</th>
                                        </tr>
                                    </thead>
                                    <?php $__currentLoopData = $data['records']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($record->id); ?> </td>
                                        <td> <?php echo e($record->created_at->format('d-m-Y')); ?> </td>
                                        <td> <?php echo e($record->created_at->format('H:i')); ?> </td>
                                        <td> <?php echo e($record->end_at->format('H:i')); ?> </td>
                                        <td> <?php echo e($record->level); ?> </td>
                                        <td> <?php echo e($record->parking_id); ?> </td>
                                        <td> <?php echo e($record->carplate); ?> </td>
                                        <td> <?php 
                                        if($record->status==1){
                                            echo "<button type='button' class='btn btn-warning ' style='font-weight:bolder;'>On-going</button>";
                                        }else if($record->status==2){
                                            echo "<button type='button' class='btn btn-danger ' style='font-weight:bolder;'>Cancelled</button>";
                                        }else{
                                            echo "<button type='button' class='btn btn-success ' style='font-weight:bolder;'>Success</button>";
                                        }
                                        ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</main>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admindash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/admin.blade.php ENDPATH**/ ?>