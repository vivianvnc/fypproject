

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid">
    <h1 class="mt-4">Reservations</h1>
<?php if($res!=NULL): ?>
    <div class="container">
         <!-- Modal -->
  <div id="myModal">
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="deleteModalLabel">Reservation</h5>
          </div>
          <?php echo e(Form::open(['action'=>'ReservationController@destroy', 'method'=>'POST'])); ?>

              <?php echo e(csrf_field()); ?>

              <input id="resID" value="<?php echo e($res['res']->id); ?>" type="hidden" name="resID">
              <input id="parkingID" value="<?php echo e($res['res']->parking_id); ?>" type="hidden" name="parkingID">
                  <div class="modal-body">
                      Are you sure you want to cancel the reservation?
                  </div>
                  <div class="modal-footer">
                  <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger', 'data-toggle'=>'button'])); ?>

                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                  </div>
              </div>
              </div>
          </div>
          <?php echo e(Form::close()); ?>

  </div>
    <div class="card-body">
        <h2>On-going Reservation:</h2><br>
        <h4>Level: <?php echo e($res['level']); ?></h4><br>
        <h4>Parking: <?php echo e($res['parking']); ?></h4><br>
        <h4>End At: <?php echo e($res['res']->end_at); ?></h4>
        <br> 
        <button id="delete" type="button" class="btn btn-danger"  data-bs-toggle="modal" data-bs-target="#deleteModal">Delete Reservation</button>
    </div>
    <script src="http://code.jquery.com/jquery-3.3.1.min.js"
    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
    <script>
        $(document).ready(function(){
        $(".btn").click(function(event){
            $('#myModal').modal('show');
        });
        })
    </script>

<?php else: ?>
<div class="row justify-content-start">
    <div class="col-5">
    <h4> You do not have any on-going reservation. </h4>
    </div>
    <div class="col-4">
    <button id="reservation" type="button" class="btn btn-primary" onclick="location.href='<?php echo e(url('levelselection')); ?>'">+ Make New Reservation</button>
    <div class="row">
          &nbsp;
    </div>
    </div>
</div>

<?php endif; ?>
</div>
<div class="container-fluid">
<div class="card mb-4">
    <div class="card-header">
        <div class="row">
            <div class="col-4">
              Reservations History
            </div>
        </div>
    </div>
    <div class="card-body">

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userdash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views//reservation.blade.php ENDPATH**/ ?>