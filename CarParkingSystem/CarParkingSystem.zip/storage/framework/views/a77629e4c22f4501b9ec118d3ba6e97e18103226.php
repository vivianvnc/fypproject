
<?php $__env->startSection('main-content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <div class="row">
            <div class="col">
            <h5 class="mt-2"> Welcome <?php echo e(Auth::user()->name); ?> ! </h5>
            </div>
        </div>
        <div class="row">
            <div class="col">
            <h5 class="mt-2">Car Plate No.: <?php echo e(Auth::user()->carplate); ?></h5>
            </div>
        </div>
        <div class="row">
            <div class="col">
            <h5 class="mt-2">Email: <?php echo e(Auth::user()->email); ?> </h5>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col">
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-chart-area mr-1"></i>
                        Your reservation today
                    </div>
                    <div class="card-body">
                    <?php if(empty($res['id'])): ?>
                    <div class="row justify-content-start">
                        <div class="col-5">
                        <h4> You do not have any on-going reservation. </h4>
                        </div>
                        <div class="col-4">
                        <button id="reservation" type="button" class="btn btn-primary" onclick="location.href='<?php echo e(url('levelselection')); ?>'">+ Make New Reservation</button>
                        <div class="row">
                              &nbsp;
                        </div>
                        </div>
                    </div>
                    <?php else: ?>
                        <h2>On-going Reservation:</h2><br>
                        <h4>Level: <?php echo e($res['level']); ?></h4><br>
                        <h4>Parking: <?php echo e($res['parking']); ?></h4><br>
                        <h4>Date: <?php echo e($res['created_at']->format('d-m-Y')); ?></h4>
                        <h4>Start At: <?php echo e($r->created_at->format('H:i')); ?></h4>
                        <h4>End At: <?php echo e($res['end_at']->format('H:i')); ?> </h4>
                        <br> 
                        <button id="delete" type="button" class="btn btn-danger"  data-bs-toggle="modal" data-bs-target="#deleteModal">Cancel Reservation</button>
                        <?php endif; ?>
                    </div>
                        </div>
                    </div>
                </div>
        </div>
</main>
<!-- Modal -->
<div id="myModal">
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Reservation</h5>
        </div>
        <?php echo e(Form::open(['action'=>'ReservationController@destroy', 'method'=>'POST'])); ?>

            <?php echo e(csrf_field()); ?>

            <input id="resID" value="<?php echo e($res['id']); ?>" type="hidden" name="resID">
            <input id="parkingID" value="<?php echo e($res['parking_id']); ?>" type="hidden" name="parkingID">
                <div class="modal-body">
                    Are you sure you want to cancel the reservation?
                </div>
                <div class="modal-footer">
                <?php echo e(Form::submit('Yes',['class'=>'btn btn-danger', 'data-toggle'=>'button'])); ?>

                <button type="button" class="btn btn-secondary" data-bs-dismiss="mymodal">No</button>
                <?php echo e(Form::close()); ?>

                </div>
            </div>
            </div>
        </div>
</div>
                         
<script src="http://code.jquery.com/jquery-3.3.1.min.js"
integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
crossorigin="anonymous"></script>
<script>
    $(document).ready(function(){
    $(".btn").click(function(event){
        $('#myModal').modal('show');
    });
    })
</script>
<?php $__env->stopSection(); ?>



        



<?php echo $__env->make('layouts.userdash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views//user.blade.php ENDPATH**/ ?>