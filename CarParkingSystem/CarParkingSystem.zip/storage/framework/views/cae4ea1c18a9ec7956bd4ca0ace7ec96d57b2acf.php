<?php $__env->startSection('sidebar'); ?>
<div class="row">
    <div class="col-2 sidebar">
        <div class="sidebar-header">
            <h3>User Dashboard</h3>
        </div>
        <ul class="list-unstyled components sidebar-nav">
                <li>
                    <a href="<?php echo e(url('/edit')); ?>">Edit Profile</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/reservation')); ?>">View Reservation</a>
                </li>
                <li>
                  <a href="#">Logout</a>
                </li>
        </ul>
    </div>
</div>

<?php $__env->stopSection(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>