

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('partials.title'); ?>
        This is Index
    <?php if (isset($__componentOriginala489dd0c771a0078af498eb97f213c65500b8cb6)): ?>
<?php $component = $__componentOriginala489dd0c771a0078af498eb97f213c65500b8cb6; ?>
<?php unset($__componentOriginala489dd0c771a0078af498eb97f213c65500b8cb6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php echo $__env->make('partials.navlinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/vivian.blade.php ENDPATH**/ ?>