<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
    <link href="<?php echo e(mix('/css/app.css')); ?>" rel="stylesheet">

        <!-- Styles -->

    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <?php $__env->startComponent('partials.title'); ?>
                    This is About page.
                <?php if (isset($__componentOriginala489dd0c771a0078af498eb97f213c65500b8cb6)): ?>
<?php $component = $__componentOriginala489dd0c771a0078af498eb97f213c65500b8cb6; ?>
<?php unset($__componentOriginala489dd0c771a0078af498eb97f213c65500b8cb6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                <div class="links">
                    <?php echo $__env->make('partials.navlinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/about.blade.php ENDPATH**/ ?>