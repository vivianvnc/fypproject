<?php $__env->startSection('rowA'); ?>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="pillar">
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="pillar">
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="pillar">
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="pillar">
</div>

<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>

<div class="pillar">
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="green-box" id="">
    <div>D01</div>
</div>
<div class="pillar">
</div>
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/parking/rowA.blade.php ENDPATH**/ ?>