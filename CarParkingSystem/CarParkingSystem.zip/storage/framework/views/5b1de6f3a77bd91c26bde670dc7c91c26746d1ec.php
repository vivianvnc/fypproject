<div class="title m-b-md">
    <?php echo e($anything); ?>

</div><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/partials/newtitle.blade.php ENDPATH**/ ?>