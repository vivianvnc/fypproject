<script>
    window.setTimeout(function() {
    $(".alert").fadeTo(500, 0)
    .slideUp(500, function(){
        $(this).remove(); 
    });
    }, 3000);
</script>


<?php if(session('success')): ?>
    <div class="alert alert-success container-fluid" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-warning container-fluid" role="alert">
        <strong><?php echo e(session('warning')); ?></strong>
  </div>
<?php endif; ?>

<?php if(session('main-error')): ?>
        <div class="alert alert-danger container-fluid" role="alert">
            <?php echo e(session('main-error')); ?>

        </div>
<?php endif; ?>
<?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/includes/alerts.blade.php ENDPATH**/ ?>