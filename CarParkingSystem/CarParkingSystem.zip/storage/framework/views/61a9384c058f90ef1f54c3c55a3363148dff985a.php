

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        
      <div class="h-100 align-items-center">
  <div class="row">
    <div class="w-50 mx-auto">
    <h2 style="text-align: center;">Car Park Reservation System</h2>
    <h5 style="text-align: center;">Please select the level of parking lots you'd like to park:</h5>
    </div>
  </div>
    <div class="row">
    <div class="w-50 mx-auto">
        <div class="w-50 mx-auto">
        <div class="select-level"><a href="/booking">
            LEVEL 1
            </a>
        </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/index.blade.php ENDPATH**/ ?>