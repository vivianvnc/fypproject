
<?php $__env->startSection('form-content'); ?>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
        $(document).ready(function () {
            var counter = 0;

            $('#addrow').on("click", function(){
                console.log('click');
                var newRow = $("<div class='form-row'>");
                var cols = "";
                cols += '<div class="col-4">';
                cols +='<input type="text" class="form-control" placeholder="ParkingID">';
                cols +='</div>';
            });


        });
    </script>
</head>
    <div class="col-md-10 offset-md-1">
        <div class="card-body">
        
        <form>
            <div class="form-row">
              <div class="col-4">
                <input type="text" class="form-control" placeholder="ParkingID">
              </div>
                <select class="selectpicker" data-style="btn-primary" data-width="100px" aria-label="Default select example">
                    <option value="available">Available</option>
                    <option value="occupied">Occupied</option>
                    <option value="reserved">Reserved</option>
                </select>
            </div>
            <br>
            <input type="button" class="btn btn-primary " id="addrow" value="Add More" />
        </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.form', array('cardtitle'=>'Add Parking'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/addParking.blade.php ENDPATH**/ ?>