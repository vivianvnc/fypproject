

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid">
        <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h1 class="mt-4">Edit Profile</h1>
        <div class="card-body">
                <?php echo e(Form::open(['action'=>'UserController@update', 'method'=>'POST'])); ?>

                
                <?php echo e(Form::label('name','Name',['class' => 'control-label'])); ?>

                <?php echo e(Form::text('name',$user[0]->name,['class'=>'form-control '])); ?>

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">*<?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <?php echo e(Form::label('email','E-mail address')); ?>

                <?php echo e(Form::text('email',$user[0]->email,['class'=>'form-control','placeholder'=>'eg. abc@email.com'])); ?>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">*<?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <?php echo e(Form::label('cpassword','New password')); ?>

                <input type="password" name="cpassword" class="form-control">
                <?php $__errorArgs = ['cpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">*<?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <br>
                <?php echo e(Form::label('password','Re-type New password')); ?>

                <input type="password" name="password" class="form-control">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">*<?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <br>
                <?php echo e(Form::label('carplate','Car Plate No.')); ?>

                <?php echo e(Form::text('carplate',$user[0]->carplate,['class'=>'form-control', 'onkeyup'=>'this.value = this.value.toUpperCase();'])); ?>

                <?php $__errorArgs = ['carplate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">*<?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <div class="row justify-content-center">
                <?php echo e(Form::submit('Save',['class'=>'btn btn-primary', 'data-toggle'=>'button'])); ?>

                
                <?php echo e(Form::close()); ?>

        </div>
</div>

<script>
$(document).on('keydown', '.carplate', function(e) {
    if (e.keyCode == 32) return false;
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userdash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views//edit.blade.php ENDPATH**/ ?>