
<?php $__env->startSection('main-content'); ?>

<!-- AddModal -->
<div id="myModal">
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="addModalLabel">Add New User</h5>
          </div>
          <?php echo e(Form::open(['url' => url('/viewusers/search/add'), 'method'=>'POST'])); ?>

                  <div class="modal-body">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(Form::label('name','Name',['class' => 'control-label'])); ?>

                        <?php echo e(Form::text('name','',['class'=>'form-control','placeholder'=>'Name'])); ?>

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('email','E-mail address')); ?>

                        <?php echo e(Form::text('email','',['class'=>'form-control','placeholder'=>'eg. abc@email.com'])); ?>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('cpassword','Create password')); ?>

                        <input type="password" name="cpassword" class="form-control" placeholder="Create password">
                        <?php $__errorArgs = ['cpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('password','Re-type password')); ?>

                        <input type="password" name="password" class="form-control" placeholder="Re-type password">
                        
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('carplate','Car Plate No.')); ?> <small>Put "N" for Admin</small>
                        <?php echo e(Form::text('carplate','',['class'=>'form-control','placeholder'=>'eg. ABC1234', 'onkeyup'=>'this.value = this.value.toUpperCase();'])); ?>

                        <?php $__errorArgs = ['carplate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('usertype','User Type')); ?>

                        <?php echo e(Form::select('usertype', array('0'=>'User', '1'=>'Admin'),'', array('class'=>'form-control'))); ?>

                        <br>
                  </div>
                  <div class="modal-footer">
                  <?php echo e(Form::submit('Add New User',['class'=>'btn btn-primary', 'data-toggle'=>'button', 'id'=>'addbtn'])); ?>

                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                  </div>
                  <?php echo e(Form::close()); ?>

              </div>
              </div>
            </div>
</div>
<script>         
    $(document).on('keydown', '#carplate', function(e) {
        if (e.keyCode == 32) return false;
    });
    $(document).on('keydown', '#e-carplate', function(e) {
        if (e.keyCode == 32) return false;
    });
</script>

<!-- EditModal -->
<div id="myModal">
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editModalLabel">Edit user data</h5>
          </div>
          <?php echo e(Form::open(['url' => url('/viewusers/search/edit'), 'method'=>'POST'])); ?>

                 <input id="selected-id" type="hidden" name="selected-id">
                  <div class="modal-body">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(Form::label('e-name','Name',['class' => 'control-label'])); ?>

                        <?php echo e(Form::text('e-name','',['class'=>'form-control '])); ?>

                        <?php $__errorArgs = ['e-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('e-email','E-mail address')); ?>

                        <?php echo e(Form::text('e-email','',['class'=>'form-control'])); ?>

                        <?php $__errorArgs = ['e-email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('e-carplate','Car Plate No.')); ?>

                        <?php echo e(Form::text('e-carplate','',['class'=>'form-control', 'onkeyup'=>'this.value = this.value.toUpperCase();'])); ?>

                        <?php $__errorArgs = ['e-carplate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error">*<?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>
                        <?php echo e(Form::label('e-usertype','User Type')); ?>

                        <?php echo e(Form::select('e-usertype', array('0'=>'User', '1'=>'Admin'),'', array('class'=>'form-control'))); ?>

                        <br>
                  </div>
                  <div class="modal-footer">
                  <?php echo e(Form::submit('Save',['class'=>'btn btn-primary', 'data-toggle'=>'button', 'id'=>'savebtn'])); ?>

                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                  </div>
                  <?php echo e(Form::close()); ?>

              </div>
              </div>
            </div>
    </div>
</div>

<!-- DeleteModal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Delete User</h5>
        </div>
                <div class="modal-body">
                </div>
                <div class="modal-footer">
                <?php echo e(Form::open(['url' => url('/viewusers/search/delete'), 'method'=>'POST'])); ?>

                <input id="userid" type="hidden" name="userid">
                <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger', 'data-toggle'=>'button'])); ?>

                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <?php echo e(Form::close()); ?>

            </div>
    </div>
    </div>
</div>

<div class="container-fluid">
<!--Content-->
<h1 class="mt-4">Users</h1>
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table mr-1"></i>
        User Data
    </div>
    <div class="row" style="padding-top:20px; padding-left:20px;">
        <div class="col-3">
        <?php echo e(Form::open(['action'=>'AdminController@searchuser', 'method'=>'POST'])); ?>

        <?php echo e(Form::text('search','',['class'=>'form-control','placeholder'=>'Search...','type'=>'search'])); ?>

        </div>
        <div class="col-3">
        <?php echo e(Form::submit('search',['class'=>'btn btn-primary', 'data-toggle'=>'button'])); ?>

        </div>
        <?php echo e(Form::close()); ?>

        <div class="col-3 align-items-end">
            <button type="button" class="btn btn-primary addbtn" data-bs-toggle="modal" data-bs-target="#addModal">+ Add New User</button>
        </div>
    </div>
    <div class="card-body">
        <?php if($users!=NULL): ?>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th scope="col"> Id</th>
                                <th scope="col"> Name</th>
                                <th scope="col"> Email </th>
                                <th scope="col"> Car Plate</th>
                                <th scope="col"> User Type</th>
                                <th scope="col"> Action </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="userID"> <?php echo e($user->id); ?> </td>
                                <td class="name"> <?php echo e($user->name); ?> </td>
                                <td class="email"> <?php echo e($user->email); ?> </td>
                                <td class="carplate"> <?php echo e($user->carplate); ?> </td>
                                <td class="usertype"><?php
                                    if($user->admin==1){
                                        echo "Admin";
                                    }
                                    else{
                                        echo "User";
                                    }
                                    ?>
                                </td>
                                <td> <button id="<?php echo e($user->id); ?>" type="button" class="btn btn-primary editbtn" data-bs-toggle="modal" data-bs-target="#editModal" data-userid="<?php echo e($user->id); ?>"
                                    data-name="<?php echo e($user->name); ?>" 
                                    data-email="<?php echo e($user->email); ?>"
                                    data-carplate="<?php echo e($user->carplate); ?>"
                                    data-usertype="<?php echo e($user->admin); ?>">Edit</button>
                                    <button id="<?php echo e($user->id); ?>" type="button" class="btn btn-danger deletebtn" data-bs-toggle="modal" data-bs-target="#deleteModal" data-userid="<?php echo e($user->id); ?>">Delete</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
        <?php else: ?>
            <p>No Users </p>
            
        <?php endif; ?>
</div>
<script src="http://code.jquery.com/jquery-3.3.1.min.js"
    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
    
<script>
    $(document).ready(function(){

        $(".editbtn").click(function(event){

            id = $(this).attr("data-userid");
            name = $(this).attr("data-name");
            email = $(this).attr("data-email");
            carplate = $(this).attr("data-carplate");
            usertype = $(this).attr("data-usertype");

            $("#selected-id").val(id);
            $('#e-name').val(name);
            $('#e-email').val(email);
            $('#e-carplate').val(carplate);
            $('#e-usertype').val(usertype);
            $('#editModal').modal('show');
        });
        
        // $("#editModal").validate({
        //     rules:{
        //         name:"required",
        //         email:"required",
        //         cpassword:"required",
        //         password:"required",
        //         carplate:"required",
        //     }
        // });
        $(".deletebtn").click(function(event){
            id = $(this).attr("data-userid");
            $("#userid").val(id);
            $(".modal-body").html("Are you sure you want to delete user ID. " + this.id + " ?"); 
            $('#deleteModal').modal('show');
        });
        $(".addbtn").click(function(event){
            $('#addModal').modal('show');
        });
        
    })
         
    $(document).on('keydown', '#carplate', function(e) {
        if (e.keyCode == 32) return false;
    });
</script>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admindash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/searchuser.blade.php ENDPATH**/ ?>