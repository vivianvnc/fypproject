
  <?php $__env->startSection('form-content'); ?>
            <div class="col-md-10 offset-md-1">
              <div class="card-body">
                <?php echo e(Form::label('fullname','Full name')); ?>

                <?php echo e(Form::text('fullname','',['class'=>'form-control ','placeholder'=>'Full name'])); ?>

                <br>
                <?php echo e(Form::label('email','E-mail address')); ?>

                <?php echo e(Form::text('email','',['class'=>'form-control','placeholder'=>'eg. abc@email.com'])); ?>

                <br>
                <?php echo e(Form::label('cpassword','Create password')); ?>

                <?php echo e(Form::text('cpassword','',['class'=>'form-control','placeholder'=>'Create password'])); ?>

                <br>
                <?php echo e(Form::label('password','Re-type password')); ?>

                <?php echo e(Form::text('password','',['class'=>'form-control','placeholder'=>'Re-type password'])); ?>

                <br>
                <?php echo e(Form::label('carplatenum','Car Plate No.')); ?>

                <?php echo e(Form::text('carplatenum','',['class'=>'form-control','placeholder'=>'eg. ABC1234'])); ?>

                <br>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.form', array('cardtitle'=>'Sign Up'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/signup.blade.php ENDPATH**/ ?>