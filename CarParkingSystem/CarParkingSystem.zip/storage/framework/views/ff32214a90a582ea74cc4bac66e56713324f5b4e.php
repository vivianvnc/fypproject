

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <div class="h-100 align-items-center">
  <div class="row" style="padding-top:60px;">
    <div class="w-50 mx-auto">
    <h1 class="mt-4" style="text-align: center; padding-bottom:30px;">Car Park Reservation System</h2>
    <h5 style="text-align: center;">Please select the level of parking lots you'd like to park:</h5>
    </div>
  </div>
    <div class="row">
    <div class="w-50 mx-auto">
        <div class="w-50 mx-auto padding-top:10px;">
        <div class="select-level"><a href="/booking">
            LEVEL 1
            </a>
        </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/levelselection.blade.php ENDPATH**/ ?>