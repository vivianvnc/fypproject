<div class="title m-b-md">
    <?php echo e($slot); ?> 
    
</div><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/partials/title.blade.php ENDPATH**/ ?>