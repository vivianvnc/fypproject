<?php $__env->startSection('content'); ?>

<div class="container">
    Car Park Reservation System
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/home.blade.php ENDPATH**/ ?>