
                <div class="links">
                <a href="/">Static</a>
                <a href="/about">About</a>
                <a href="/index">Index</a>
                <a href="/registration">Registration</a>
                </div>
    
<?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/partials/navlinks.blade.php ENDPATH**/ ?>