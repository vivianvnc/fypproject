

<?php $__env->startSection('main-content'); ?>

<div class="container-fluid">
    <h1 class="mt-4">Make Reservation</h1>
    <h6>Click the button below to view parking space status and make reservation:</h6>
    <button class="btn btn-primary" onclick="window.location='<?php echo e(url('levelselection')); ?>'"> Parking Level Selection</button>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userdash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/makereservation.blade.php ENDPATH**/ ?>