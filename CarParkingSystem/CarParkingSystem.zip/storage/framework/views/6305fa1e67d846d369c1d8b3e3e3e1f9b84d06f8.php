
  <?php $__env->startSection('form-content'); ?>
            <div class="col-md-10 offset-md-1">
              <div class="card-body">
                <?php echo e(Form::open(['action'=>'UserController@index', 'method'=>'POST'])); ?>

                <?php echo e(csrf_field()); ?>

                <?php echo e(Form::label('email','E-mail address')); ?>

                <?php echo e(Form::text('email','',['class'=>'form-control','placeholder'=>'eg. abc@email.com'])); ?>

                <br>
                <?php echo e(Form::label('password','Password')); ?>

                <?php echo e(Form::text('password','',['class'=>'form-control','placeholder'=>'Password'])); ?>

                <br>
                <div class="row justify-content-center">
                <?php echo e(Form::submit('Login',['class'=>'btn btn-primary', 'data-toggle'=>'button'])); ?>

                  
                <?php echo e(Form::close()); ?>

                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.form', array('cardtitle'=>'Login'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views//userlogin.blade.php ENDPATH**/ ?>