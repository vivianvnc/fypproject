
<?php $__env->startSection('main-content'); ?>

<div class="container-fluid">
<!--Content-->
<h1 class="mt-4">Reservations</h1>
<div class="card mb-4">
    <div class="card-header">
        <div class="row justify-content-between">
            <div class="col-4">
              Reservation Data
            </div>
            <div class="col-3 align-self-end">
            <?php echo e(Form::open(['action'=>'AdminController@searchres', 'method'=>'POST'])); ?>

            
            <?php echo e(Form::date('date', '', array('class' => 'datepicker','id' => 'datepicker'))); ?>  
            <?php echo e(Form::submit('Search',['class'=>'btn btn-primary', 'data-toggle'=>'button'])); ?>

            </div>
            <?php echo e(Form::close()); ?>

        </div>
        
    </div>
    <div class="card-body">
        <?php if(empty($res[0]['id'])): ?>
            No reservations have been made.
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th scope="col"> Id</th>
                        <th scope="col"> Date </th>
                        <th scope="col"> Start Time </th>
                        <th scope="col"> End Time</th>
                        <th scope="col"> Parking Level</th>
                        <th scope="col"> Parking ID </th>
                        <th scope="col"> Car Plate</th>
                        <th scope="col"> Status</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($r->id); ?> </td>
                    <td> <?php echo e($r->created_at->format('d-m-Y')); ?> </td>
                    <td> <?php echo e($r->created_at->format('H:i')); ?> </td>
                    <td> <?php echo e($r->end_at->format('H:i')); ?> </td>
                    <td> <?php echo e($r->level); ?> </td>
                    <td> <?php echo e($r->parking_id); ?> </td>
                    <td> <?php echo e($r->carplate); ?> </td>
                    <td> <?php 
                    if($r->status==1){
                        echo "<button type='button' class='btn btn-warning ' style='font-weight:bolder; pointer-events: none;'>On-going</button>";
                    }else if($r->status==2){
                        echo "<button type='button' class='btn btn-danger ' style='font-weight:bolder; pointer-events: none;'>Cancelled</button>";
                    }else{
                        echo "<button type='button' class='btn btn-success ' style='font-weight:bolder; pointer-events: none;'>Success</button>";
                    }
                    ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admindash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/viewreservations.blade.php ENDPATH**/ ?>