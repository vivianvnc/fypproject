<?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->startSection('form-content'); ?>
  <div class="card-header">Login</div>
    <div class="col-md-10 offset-md-1">
      <div class="card-body">
        <?php echo e(Form::open(['action'=>'UserController@index', 'method'=>'POST'])); ?>

        <?php echo e(csrf_field()); ?>

        <?php echo e(Form::label('email','E-mail address')); ?>

        <?php echo e(Form::text('email','',['class'=>'form-control','placeholder'=>'eg. abc@email.com'])); ?>

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error">*<?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <?php echo e(Form::label('password','Password')); ?>

        <input type="password" name="password" class="form-control" placeholder="Passsword">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error">*<?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <div class="row justify-content-center">
        <?php echo e(Form::submit('Login',['class'=>'btn btn-primary', 'data-toggle'=>'button'])); ?>

        </div>
        <br>
        <?php echo e(Form::close()); ?>

        </div>
      </div>
    </div>
    <br>
    If you do not have an account, click here to <a href="/usersignup">Sign Up!</a>          
  </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vivia\Desktop\CarParkingSystem\CarParkingSystem\resources\views/auth/login.blade.php ENDPATH**/ ?>